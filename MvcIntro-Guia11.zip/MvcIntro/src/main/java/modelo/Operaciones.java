package modelo;

// Se eliminan las importaciones de java.sql porque
// ya no se utiliza una base de datos en esta versión sin persistencia.
import javabeans.*;
import java.util.*;

public class Operaciones {

    /**
     * Lista estática en memoria para almacenar mensajes.
     *
     * <p>
     * Para poder ejecutar la aplicación sin necesidad de una base de datos
     * real (ideal para sacar capturas de pantalla o hacer pruebas en
     * entornos donde MySQL no está instalado), reemplazamos todas las
     * operaciones de persistencia por una lista en memoria.  Cada
     * instancia del bean {@link MensajeBean} que se grabe mediante
     * {@link #grabaMensaje(MensajeBean)} se añadirá a esta lista.  La
     * consulta {@link #obtenerMensajes(String)} filtrará sobre esta lista
     * por el destinatario.
     * </p>
     */
    private static final List<MensajeBean> MENSAJES = new ArrayList<>();

    /**
     * Obtiene los mensajes asociados a un destinatario concreto desde la
     * lista en memoria.
     *
     * @param destino nombre del destinatario por el que se filtrarán los
     *                mensajes.
     * @return una lista con los mensajes encontrados; si no hay
     *         coincidencias, la lista estará vacía.
     */
    public ArrayList<MensajeBean> obtenerMensajes(String destino) {
        ArrayList<MensajeBean> resultado = new ArrayList<>();
        if (destino == null) {
            return resultado;
        }
        for (MensajeBean m : MENSAJES) {
            if (destino.equals(m.getDestino())) {
                resultado.add(m);
            }
        }
        return resultado;
    }

    /**
     * Agrega un mensaje nuevo a la lista en memoria.
     *
     * @param m el mensaje a guardar.
     * @return {@code true} si el mensaje se añadió correctamente;
     *         {@code false} en caso contrario.
     */
    public boolean grabaMensaje(MensajeBean m) {
        if (m == null) {
            return false;
        }
        return MENSAJES.add(m);
    }
}
